import { PROFILES } from '../data/mockData'

const LABELS = {
  ramp: 'wheelchair ramps',
  elevator: 'elevator access',
  accessibleBathroom: 'an accessible bathroom',
  wideEntrance: 'a wide entrance',
  accessibleParking: 'accessible parking',
  quietEnvironment: 'quiet-hour options',
  accessibleTransport: 'accessible transport links',
}

// Turns selected profile ids + a place's attributes into a plain-language
// explanation, standing in for a natural-language model call. Swapping this
// for a real LLM API is a one-function change — see README.
export function explainMatch(place, selectedProfiles) {
  const profileLabels = selectedProfiles
    .map((id) => PROFILES.find((p) => p.id === id)?.label.toLowerCase())
    .filter(Boolean)

  const present = Object.entries(place.attrs)
    .filter(([, v]) => v)
    .map(([k]) => LABELS[k])

  if (!profileLabels.length) {
    return `${place.name} provides ${present.slice(0, 3).join(', ') || 'limited accessibility features'}.`
  }

  const subject = profileLabels.length > 1
    ? `travellers who need ${profileLabels.slice(0, -1).join(', ')} and ${profileLabels[profileLabels.length - 1]} support`
    : `${profileLabels[0]} travellers`

  if (present.length === 0) {
    return `Based on your requirements, ${place.name} does not report any of the accessibility features ${subject} typically need. Consider one of the other options.`
  }

  return `Based on your requirements, ${place.name} is a good match for ${subject} because it provides ${present.slice(0, 4).join(', ')}.`
}

// Flags places whose marketing copy implies a certain experience but whose
// recorded attributes contradict or omit the accessibility info that claim
// depends on.
const RISK_WORDS = [
  { pattern: /heritage|traditional|colonial|fort|historic/i, requires: ['elevator', 'ramp'] },
  { pattern: /rooftop|hill|multi-?storey|floors?/i, requires: ['elevator'] },
]

export function detectMismatch(place) {
  for (const rule of RISK_WORDS) {
    if (rule.pattern.test(place.description)) {
      const missing = rule.requires.filter((r) => !place.attrs[r])
      if (missing.length) {
        return `This property may not be suitable for wheelchair or mobility-limited travellers — the listing's description suggests a multi-level or heritage building, but ${missing
          .map((m) => LABELS[m])
          .join(' and ')} ${missing.length > 1 ? 'are' : 'is'} not confirmed.`
      }
    }
  }
  return null
}
