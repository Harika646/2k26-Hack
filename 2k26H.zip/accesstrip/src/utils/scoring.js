// Accessibility Score = Ramp×20 + Elevator×20 + AccessibleBathroom×20
//                       + WideEntrance×10 + AccessibleParking×10
//                       + QuietEnvironment×10 + AccessibleTransport×10
const WEIGHTS = {
  ramp: 20,
  elevator: 20,
  accessibleBathroom: 20,
  wideEntrance: 10,
  accessibleParking: 10,
  quietEnvironment: 10,
  accessibleTransport: 10,
}

export function accessibilityScore(attrs) {
  return Object.entries(WEIGHTS).reduce(
    (total, [key, weight]) => total + (attrs[key] ? weight : 0),
    0
  )
}

export function scoreTier(score) {
  if (score >= 90) return { label: 'Excellent', tone: 'success' }
  if (score >= 75) return { label: 'Good', tone: 'success' }
  if (score >= 50) return { label: 'Moderate', tone: 'warn' }
  return { label: 'Poor', tone: 'danger' }
}

// How much of a profile's needs a place satisfies, as a percentage match.
// This powers "Hotel A — 92% match" style copy, separate from the raw
// accessibility score (a place can score well overall but still be a poor
// personal match for a specific traveller).
const PROFILE_NEEDS = {
  wheelchair: ['ramp', 'elevator', 'accessibleBathroom', 'wideEntrance'],
  elderly: ['elevator', 'accessibleBathroom', 'accessibleTransport'],
  visual: ['wideEntrance', 'accessibleTransport'],
  hearing: ['accessibleTransport'],
  stroller: ['ramp', 'elevator', 'wideEntrance'],
  quiet: ['quietEnvironment'],
}

export function personalMatch(attrs, selectedProfiles) {
  if (!selectedProfiles.length) return null
  const needed = new Set()
  selectedProfiles.forEach((p) => (PROFILE_NEEDS[p] || []).forEach((n) => needed.add(n)))
  if (!needed.size) return null
  const met = [...needed].filter((n) => attrs[n])
  return {
    percent: Math.round((met.length / needed.size) * 100),
    met: met,
    missing: [...needed].filter((n) => !attrs[n]),
  }
}
