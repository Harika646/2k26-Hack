import { useMemo, useState } from 'react'
import Header from './components/Header'
import Hero from './components/Hero'
import ProfileSelector from './components/ProfileSelector'
import DestinationSearch from './components/DestinationSearch'
import ResultCard from './components/ResultCard'
import RouteCompare from './components/RouteCompare'
import Footer from './components/Footer'
import TripSummary from './components/TripSummary'
import { PLACES, ATTRACTIONS, ROUTES, DESTINATIONS, TRANSPORT_COST } from './data/mockData'
import { accessibilityScore, personalMatch } from './utils/scoring'

export default function App() {
  const [selectedProfiles, setSelectedProfiles] = useState(['wheelchair', 'elderly'])
  const [destination, setDestination] = useState('tirupati')

  const toggleProfile = (id) => {
    setSelectedProfiles((prev) =>
      prev.includes(id) ? prev.filter((p) => p !== id) : [...prev, id]
    )
  }

  const places = PLACES[destination] || []
  const attractions = ATTRACTIONS[destination] || []
  const routes = ROUTES[destination] || []
  const destInfo = DESTINATIONS.find((d) => d.id === destination)
  const destLabel = destInfo ? `${destInfo.from} → ${destInfo.to}` : ''

  const rankBy = (list) =>
    [...list].sort((a, b) => {
      const matchA = personalMatch(a.attrs, selectedProfiles)?.percent ?? 0
      const matchB = personalMatch(b.attrs, selectedProfiles)?.percent ?? 0
      if (matchA !== matchB) return matchB - matchA
      return accessibilityScore(b.attrs) - accessibilityScore(a.attrs)
    })

  const rankedPlaces = useMemo(() => rankBy(places), [places, selectedProfiles])
  const rankedAttractions = useMemo(() => rankBy(attractions), [attractions, selectedProfiles])

  const needsAccessible = selectedProfiles.length > 0

  return (
    <>
      <Header />
      <Hero />

      <main className="container">
        <ProfileSelector selected={selectedProfiles} onToggle={toggleProfile} />
        <DestinationSearch selected={destination} onSelect={setDestination} />

        <section className="section" aria-labelledby="summary-heading">
          <h2 className="section-title" id="summary-heading">3. Recommendation &amp; cost estimate</h2>
          <p className="section-desc">
            One combined pick, with an estimated total cost per person for a short trip.
          </p>
          <TripSummary
            destinationLabel={destLabel}
            places={places}
            attractions={attractions}
            transportCost={TRANSPORT_COST[destination] || 0}
            selectedProfiles={selectedProfiles}
          />
        </section>

        <section className="section" aria-labelledby="results-heading">
          <h2 className="section-title" id="results-heading">4. Ranked stays</h2>
          <p className="section-desc">
            Sorted by how well each place matches the needs you selected, not by price or star rating.
          </p>
          {rankedPlaces.length === 0 ? (
            <p className="empty-state">No listings for this route yet.</p>
          ) : (
            <div className="results-grid">
              {rankedPlaces.map((place) => (
                <ResultCard key={place.id} place={place} selectedProfiles={selectedProfiles} />
              ))}
            </div>
          )}
        </section>

        <section className="section" aria-labelledby="attractions-heading">
          <h2 className="section-title" id="attractions-heading">5. Tourist places to visit</h2>
          <p className="section-desc">
            Entry costs and accessibility scores for the main attractions on this route.
          </p>
          {rankedAttractions.length === 0 ? (
            <p className="empty-state">No attractions listed for this route yet.</p>
          ) : (
            <div className="results-grid">
              {rankedAttractions.map((place) => (
                <ResultCard key={place.id} place={place} selectedProfiles={selectedProfiles} />
              ))}
            </div>
          )}
        </section>

        <section className="section" aria-labelledby="route-heading">
          <h2 className="section-title" id="route-heading">6. Accessibility-aware route</h2>
          <p className="section-desc">
            {needsAccessible
              ? 'We prioritise a step-free path over the shortest one whenever you have accessibility needs selected.'
              : 'Select a need above to see how the recommended route changes.'}
          </p>
          <RouteCompare routes={routes} needsAccessible={needsAccessible} />
        </section>
      </main>

      <Footer />
    </>
  )
}
