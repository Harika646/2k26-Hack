export default function Header() {
  return (
    <header className="site-header">
      <div className="container">
        <div className="brand">
          <span className="brand-mark" aria-hidden="true">✦</span>
          AccessTrip
        </div>
        <span className="brand-tag">Travel without barriers.</span>
      </div>
    </header>
  )
}
