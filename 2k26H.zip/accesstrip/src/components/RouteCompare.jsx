const WAYPOINT_META = {
  start: { icon: '●', label: 'Start', tone: 'neutral' },
  end: { icon: '◆', label: 'End', tone: 'neutral' },
  road: { icon: '—', label: 'Road', tone: 'neutral' },
  ramp: { icon: '♿', label: 'Ramp', tone: 'good' },
  elevator: { icon: '🛗', label: 'Elevator', tone: 'good' },
  stairs: { icon: '⚠', label: 'Stairs', tone: 'bad' },
}

function Ribbon({ waypoints }) {
  return (
    <div className="route-ribbon" aria-hidden="true">
      {waypoints.map((wp, i) => {
        const meta = WAYPOINT_META[wp]
        return (
          <div key={i} style={{ display: 'contents' }}>
            <div className="wp">
              <div className={`wp-dot ${meta.tone === 'good' ? 'good' : meta.tone === 'bad' ? 'bad' : ''}`}>
                {meta.icon}
              </div>
              <div className="wp-label">{meta.label}</div>
            </div>
            {i < waypoints.length - 1 && <div className="wp-line" />}
          </div>
        )
      })}
    </div>
  )
}

export default function RouteCompare({ routes, needsAccessible }) {
  // If the traveller selected any need, prioritise the fully accessible
  // route even though it may be longer — this is the core "accessible
  // route, not shortest route" behaviour from the brief.
  const recommendedId = needsAccessible
    ? routes.find((r) => !r.stairs)?.id ?? routes[0].id
    : routes.reduce((best, r) => (r.distanceKm < best.distanceKm ? r : best)).id

  return (
    <div className="route-compare">
      {routes.map((r) => {
        const isRecommended = r.id === recommendedId
        return (
          <div key={r.id} className={`route-card${isRecommended ? ' recommended' : ''}`}>
            <div className="route-top">
              <div className="route-title">{r.label}</div>
              <div className="route-meta">{r.distanceKm} km · {'★'.repeat(r.stars)}{'☆'.repeat(5 - r.stars)}</div>
            </div>
            <Ribbon waypoints={r.waypoints} />
            {isRecommended && (
              <div className="route-recommend-tag">
                ✓ Recommended for your selected needs
                {needsAccessible && r.distanceKm !== Math.min(...routes.map((x) => x.distanceKm)) && (
                  <> — {(r.distanceKm - Math.min(...routes.map((x) => x.distanceKm))).toFixed(1)} km longer, fully accessible</>
                )}
              </div>
            )}
          </div>
        )
      })}
    </div>
  )
}
