import { accessibilityScore, personalMatch } from '../utils/scoring'

const NIGHTS = 2
const TOP_ATTRACTIONS_COUNT = 3

function bestByMatch(items, selectedProfiles) {
  return [...items].sort((a, b) => {
    const matchA = personalMatch(a.attrs, selectedProfiles)?.percent ?? 0
    const matchB = personalMatch(b.attrs, selectedProfiles)?.percent ?? 0
    if (matchA !== matchB) return matchB - matchA
    return accessibilityScore(b.attrs) - accessibilityScore(a.attrs)
  })
}

export default function TripSummary({ destinationLabel, places, attractions, transportCost, selectedProfiles }) {
  const rankedHotels = bestByMatch(places, selectedProfiles)
  const rankedAttractions = bestByMatch(attractions, selectedProfiles)

  const topHotel = rankedHotels[0]
  const topAttractions = rankedAttractions.slice(0, TOP_ATTRACTIONS_COUNT)

  const hotelTotal = topHotel ? topHotel.price * NIGHTS : 0
  const attractionsTotal = topAttractions.reduce((sum, a) => sum + a.cost, 0)
  const grandTotal = hotelTotal + attractionsTotal + transportCost

  const inr = (n) => `₹${n.toLocaleString('en-IN')}`

  return (
    <div className="result-card" style={{ background: 'linear-gradient(180deg, #FFFFFF, #FBFAF6)' }}>
      <h3 className="result-name">Our recommendation for {destinationLabel}</h3>
      <p className="result-desc" style={{ marginTop: 8 }}>
        {topHotel
          ? `Stay at ${topHotel.name}, plus ${topAttractions.length} top-matched attraction${topAttractions.length === 1 ? '' : 's'}, for a ${NIGHTS}-night trip.`
          : 'Select a destination to see a full cost breakdown.'}
      </p>

      <div className="feature-tags" style={{ marginTop: 18, flexDirection: 'column', alignItems: 'stretch', gap: 8 }}>
        {topHotel && (
          <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 14 }}>
            <span>🏨 {topHotel.name} · {NIGHTS} nights</span>
            <span className="mono">{inr(hotelTotal)}</span>
          </div>
        )}
        {topAttractions.map((a) => (
          <div key={a.id} style={{ display: 'flex', justifyContent: 'space-between', fontSize: 14 }}>
            <span>📍 {a.name}</span>
            <span className="mono">{a.cost === 0 ? 'Free' : inr(a.cost)}</span>
          </div>
        ))}
        <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 14 }}>
          <span>🚗 Round-trip transport (est.)</span>
          <span className="mono">{inr(transportCost)}</span>
        </div>
      </div>

      <div
        style={{
          marginTop: 16,
          paddingTop: 14,
          borderTop: '1px solid var(--color-line)',
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'baseline',
        }}
      >
        <span style={{ fontWeight: 600 }}>Estimated total per person</span>
        <span className="mono" style={{ fontSize: 22, fontWeight: 700 }}>{inr(grandTotal)}</span>
      </div>
    </div>
  )
}
