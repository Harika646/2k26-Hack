export default function Footer() {
  return (
    <footer className="site-footer">
      <div className="container">
        AccessTrip — a hackathon demo. Accessibility data shown here is illustrative,
        not verified against real venues.
      </div>
    </footer>
  )
}
