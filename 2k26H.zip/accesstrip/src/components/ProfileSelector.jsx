import { PROFILES } from '../data/mockData'

export default function ProfileSelector({ selected, onToggle }) {
  return (
    <section className="section" id="profile" aria-labelledby="profile-heading">
      <h2 className="section-title" id="profile-heading">1. Who are you travelling with?</h2>
      <p className="section-desc">
        Select every need that applies. Your matches and route recommendations update instantly.
      </p>
      <div className="profile-grid" role="group" aria-label="Accessibility needs">
        {PROFILES.map((p) => {
          const active = selected.includes(p.id)
          return (
            <button
              key={p.id}
              type="button"
              className={`profile-chip${active ? ' active' : ''}`}
              aria-pressed={active}
              onClick={() => onToggle(p.id)}
            >
              <span className="icon" aria-hidden="true">{p.icon}</span>
              {p.label}
            </button>
          )
        })}
      </div>
    </section>
  )
}
