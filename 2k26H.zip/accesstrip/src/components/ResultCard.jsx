import ScoreBadge from './ScoreBadge'
import { accessibilityScore, personalMatch } from '../utils/scoring'
import { explainMatch, detectMismatch } from '../utils/recommend'

const FEATURE_LABELS = {
  ramp: 'Ramp',
  elevator: 'Elevator',
  accessibleBathroom: 'Accessible bathroom',
  wideEntrance: 'Wide entrance',
  accessibleParking: 'Accessible parking',
  quietEnvironment: 'Quiet hours',
  accessibleTransport: 'Accessible transport',
}

export default function ResultCard({ place, selectedProfiles }) {
  const score = accessibilityScore(place.attrs)
  const match = personalMatch(place.attrs, selectedProfiles)
  const mismatch = detectMismatch(place)
  const isAttraction = place.cost !== undefined
  const priceValue = isAttraction ? place.cost : place.price
  const priceText = isAttraction
    ? (priceValue === 0 ? 'Free entry' : `₹${priceValue.toLocaleString('en-IN')} entry`)
    : `₹${priceValue.toLocaleString('en-IN')}/night`

  return (
    <article className="result-card">
      <div className="result-top">
        <div>
          <h3 className="result-name">{place.name}</h3>
          <p className="result-desc">{place.description}</p>
        </div>
        <div className="result-price mono">{priceText}</div>
      </div>

      <div className="badge-row" style={{ marginTop: 14 }}>
        <ScoreBadge score={score} />
        {match && <span className="match-pill">{match.percent}% match for you</span>}
      </div>

      <div className="feature-tags">
        {Object.entries(place.attrs).map(([key, has]) => (
          <span key={key} className={`feature-tag ${has ? 'yes' : 'no'}`}>
            {has ? '✓' : '✕'} {FEATURE_LABELS[key]}
          </span>
        ))}
      </div>

      {place.caveat && (
        <div className="feature-tags" style={{ marginTop: 0 }}>
          <span className="feature-tag">⚠️ {place.caveat}</span>
        </div>
      )}

      {selectedProfiles.length > 0 && (
        <div className="ai-note">
          <strong>AI recommendation.</strong> {explainMatch(place, selectedProfiles)}
        </div>
      )}

      {mismatch && (
        <div className="issue-banner" role="alert">
          <span aria-hidden="true">⚠️</span>
          <span><strong>Accessibility concern:</strong> {mismatch}</span>
        </div>
      )}
    </article>
  )
}
