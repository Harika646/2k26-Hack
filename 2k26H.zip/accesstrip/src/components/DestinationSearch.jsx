import { DESTINATIONS } from '../data/mockData'

export default function DestinationSearch({ selected, onSelect }) {
  return (
    <section className="section" aria-labelledby="dest-heading">
      <h2 className="section-title" id="dest-heading">2. Where are you headed?</h2>
      <p className="section-desc">Pick a route to see accessibility-scored stays and path options.</p>
      <div className="search-bar" role="group" aria-label="Destinations">
        {DESTINATIONS.map((d) => (
          <button
            key={d.id}
            type="button"
            className={`dest-btn${selected === d.id ? ' active' : ''}`}
            aria-pressed={selected === d.id}
            onClick={() => onSelect(d.id)}
          >
            {d.from} → {d.to}
          </button>
        ))}
      </div>
    </section>
  )
}
