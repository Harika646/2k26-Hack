import { scoreTier } from '../utils/scoring'

export default function ScoreBadge({ score }) {
  const tier = scoreTier(score)
  return (
    <span className={`score-badge ${tier.tone}`}>
      <span className="score-dot" aria-hidden="true" />
      {score}/100 · {tier.label}
    </span>
  )
}
