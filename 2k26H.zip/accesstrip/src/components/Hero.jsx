import { useEffect, useState } from 'react'

export default function Hero() {
  const targetScore = 92
  const [score, setScore] = useState(0)

  useEffect(() => {
    const timeout = setTimeout(() => setScore(targetScore), 150)
    return () => clearTimeout(timeout)
  }, [])

  return (
    <section className="hero">
      <div className="container hero-grid">
        <div>
          <span className="hero-eyebrow">Accessibility-first travel planning</span>
          <h1>Every place tells you the price. We tell you if you can actually get in.</h1>
          <p className="hero-sub">
            AccessTrip scores hotels, attractions, and routes against the needs that
            matter to you — ramps, elevators, quiet hours, step-free paths — and explains
            every recommendation in plain language.
          </p>
        </div>
        <div className="dial-card">
          <div className="dial-label">Sample accessibility score</div>
          <div className="dial-row">
            <div className="dial-number mono">{score}</div>
            <div className="dial-bar-track">
              <div className="dial-bar-fill" style={{ width: `${score}%` }} />
            </div>
          </div>
          <div className="dial-hotel-name">Hotel Srinivasa Residency — 92% match</div>
          <div className="dial-caption">Elevator · Ramp · Accessible bathroom · Ground-floor rooms</div>
        </div>
      </div>
    </section>
  )
}
